"use client";

// ... (truncated for brevity, same code as above)

export default AutoDevisForm;
